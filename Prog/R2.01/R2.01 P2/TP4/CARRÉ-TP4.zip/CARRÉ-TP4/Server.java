package notification;
import java.util.HashMap;
import java.util.Map;
/**
 * 
 * @author L. Carré
 * @version 1.0
*/
public class Server {

    
    /**
     * Stocke les abonnements des utilisateurs sous forme (nom, abonné)
     */
    private Map<String, Subscriber> abonnements;

    /**
     * Constructeur de Server : initialise la structure de stockage des abonnés
     */
    public Server() {
        this.abonnements = new HashMap<>();
	}
	
	/**
	 * Method which adds a subscription for a new customer identified by 
	 * his name and according to a modality for the address provided
	 * @param clientName name of the client
	 * @param mode communication mode chosen by the subscriber
	 * @param adr address of the subscriber
	 */
	public void adherer(String clientName, String mode, String adr) {
		if (abonnements.containsKey(clientName)) {
            System.out.println("Le client est déjà inscrit.");
        } else {
	        CommunicationStrategy strategy = CommunicationFactory.create(mode);
			if (strategy == null) {
				System.out.println("Mode de communication invalide.");
			} else {
				Subscriber subscriber = new Subscriber(clientName, mode, adr, strategy);
				abonnements.put(clientName, subscriber);
			}
		}
	}
	
	/**
	 * Method which withdraws membership from the alert service for the named 
	 * customer if he is a member, otherwise displays a message of error.
	 * @param clientName name of the client
	 */
	public void retirer(String clientName) {
		if (abonnements.containsKey(clientName)) {
			abonnements.remove(clientName);
		} else {
			System.out.println("Aucun client trouvé.");
		}
	}
	
	/**
	 * Method which sends the message passed as a parameter to all subscribers 
	 * according to the method they have chosen.
	 * @param message message sent to everyone
	 */
	public void alerter(String message) {
		if (message == null || message == "") {
            System.out.println("Message vide, alerte non envoyée.");
        } else {
			for (Subscriber abonne : abonnements.values()) {
				abonne.getStrategy().envoyer(abonne.getNom(), abonne.getAdresse(), message);
			}
        }
	}
	
	/**
	 * Method which returns in the form of an array of channels the list of subscribers 
	 * according to the format for each string: “NomDuClient  (modeChoisi)”
	 * @return The list of subscribers
	 */
	public String[] getListeInscrits() {
		String[] ret = new String[abonnements.size()];
		int i = 0;
		for (Subscriber abonne : abonnements.values()) {
			ret[i] = abonne.getNom() + " " + abonne.getAdresse() + " (" + abonne.getMode() + ")";
			i++;
		}
		return ret;
	}
}
